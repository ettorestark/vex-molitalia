var authApi = myScript.authApi;//'3909defe7a80b99cd46086b869ee3f7482732903';
var latInit =  myScript.latInit;
var lngInit = myScript.longInit;

console.log(myScript.urbanerPluginUrl + "get_price_urbaner.php");

function initMap() {
                //google.maps.event.addDomListener(window, "load", initialize);
                var directionsDisplay = new google.maps.DirectionsRenderer({
                    suppressMarkers: true
                });
                var directionsService = new google.maps.DirectionsService();


                var latlng = new google.maps.LatLng(latInit, lngInit)
                var  map = new google.maps.Map(document.getElementById('map'), {
                  center: latlng,
                  zoom: 12
                });
                var marker = new google.maps.Marker({
                    position: new google.maps.LatLng(latInit, lngInit),
                    map: map,
                    title: 'Locacion de la tienda'
                });

                 var input = document.getElementById("billing_address_1");
                var autocomplete = new google.maps.places.Autocomplete(input);
                var marker2 = new google.maps.Marker({
                        //position: new google.maps.LatLng(place.geometry["location"].lat(), place.geometry["location"].lng() ),
                        map: map,                        
                        draggable:true,
                        animation: google.maps.Animation.DROP
                        //title: 'Direccion de envio'
                    });
                var markers = [marker, marker2];
                var bounds = new google.maps.LatLngBounds();                

                directionsDisplay.setMap(map);

                autocomplete.addListener("place_changed", function () {
                    var place = autocomplete.getPlace();
                    // place variable will have all the information you are looking for.                    
                    
                    marker2.setPosition(place.geometry.location);
                    //marker2.setVisible(true);

                    for (var i = 0; i < markers.length; i++) {
                     bounds.extend(markers[i].getPosition());
                    }

                    map.fitBounds(bounds);       

                    function calculateRoute(){
                        var request = {
                            origin: latlng,
                            destination: place.geometry.location,
                            travelMode: 'DRIVING'
                        };
                        directionsService.route(request, function(result, status){
                            if(status == "OK"){
                                directionsDisplay.setDirections(result);
                            }
                        });

                        jQuery.ajax({
                            type:"POST", 
                            url: myScript.urbanerPluginUrl + "get_price_urbaner.php",
                            data:{
                                funcion: "calculatePrice",
                                latlngOrigin: latInit+','+lngInit,
                                latlngDestination: place.geometry.location.lat()+','+place.geometry.location.lng(),
                                vehicle_id: jQuery("input[name='package_type.id']:checked").val(),
                                return: 'false',
                                authorization:"token "+authApi,
                                type: jQuery("input[name='type']:checked").val()
                                }, 
                            success:function(datos){ 
                                 console.log(datos);
                                 jQuery('#latlngurbaner').val(place.geometry.location.lat()+','+place.geometry.location.lng());
                                 jQuery('body').trigger('update_checkout');
                             }
                            
                        });
                    }
                    calculateRoute();
                    
                });


                google.maps.event.addListener(marker2, 'dragend', function() 
                {   
                    var bounds = new google.maps.LatLngBounds();
                    for (var i = 0; i < markers.length; i++) {
                     bounds.extend(markers[i].getPosition());
                    }
                    map.fitBounds(bounds);
                    geocodePosition(marker2.getPosition());

                    function calculateRoute(){
                        var request = {
                            origin: latlng,
                            destination: marker2.getPosition(),
                            travelMode: 'DRIVING'
                        };
                        directionsService.route(request, function(result, status){
                            if(status == "OK"){
                                directionsDisplay.setDirections(result);
                            }
                        });
                        jQuery.ajax({
                            type:"POST", 
                            url: myScript.urbanerPluginUrl + "get_price_urbaner.php",
                            data:{
                                funcion: "calculatePrice",
                                latlngOrigin: latInit+','+lngInit,
                                latlngDestination: marker2.getPosition().lat()+','+marker2.getPosition().lng(),
                                vehicle_id: jQuery("input[name='package_type.id']:checked").val(),
                                return: 'false',
                                authorization:"token "+authApi,
                                type: jQuery("input[name='type']:checked").val()
                                }, 
                            success:function(datos){ 
                                jQuery('#latlngurbaner').val(marker2.getPosition().lat()+','+marker2.getPosition().lng());
                                 if(datos.error){
                                    alert(datos.error);
                                 }
                                 jQuery('body').trigger('update_checkout', function (e){
                                        e.preventDefault();
                                     });
                                 
                             },
                             error: function (xhr, ajaxOptions, thrownError) {
                                console.log(xhr.status);
                                console.log(thrownError);
                                console.log(xhr.responseText);
                              }
                            });
                    }
                    calculateRoute();
                });

                jQuery("input[type=radio][name='package_type.id']").change(function(){
                    try{
                        function calculateRoute(){
                           jQuery.ajax({
                                type:"POST", 
                                url: myScript.urbanerPluginUrl + "get_price_urbaner.php",
                                data:{
                                    funcion: "calculatePrice",
                                    latlngOrigin: latInit+','+lngInit,
                                    latlngDestination: marker2.getPosition().lat()+','+marker2.getPosition().lng(),
                                    vehicle_id: jQuery("input[name='package_type.id']:checked").val(),
                                    return: 'false',
                                    authorization:"token "+authApi,
                                    type: jQuery("input[name='type']:checked").val()
                                    }, 
                                success:function(datos){ 
                                     console.log("Update checkout precios");console.log(datos);
                                     jQuery('#latlngurbaner').val(marker2.getPosition().lat()+','+marker2.getPosition().lng());
                                     
                                     if(datos.error){
                                        jQuery("#type1").prop("disabled", true);
                                        jQuery("#type3").prop("checked", true);
                                        alert(datos.error);
                                        //calculateRoute();
                                     }
                                     else{                                        
                                        jQuery("#type1").prop("disabled", false);
                                     }
                                    jQuery('body').trigger('update_checkout');
                                     
                                 }
                                });
                        }
                        calculateRoute();
                        //var elmnt = document.getElementById("shipping_method_0_urbaner");
                        //                elmnt.scrollIntoView();
                    }
                    catch(err) {
                        alert("Escriba su dirección de entrega y seleccione el punto en el mapa");
                    }                    
                });
                jQuery("input[type=radio][name='type']").change(function(){
                    try {
                        
                          function calculateRoute(){
                           jQuery.ajax({
                                type:"POST", 
                                url: myScript.urbanerPluginUrl + "get_price_urbaner.php",
                                data:{
                                    funcion: "calculatePrice",
                                    latlngOrigin: latInit+','+lngInit,
                                    latlngDestination: marker2.getPosition().lat()+','+marker2.getPosition().lng(),
                                    vehicle_id: jQuery("input[name='package_type.id']:checked").val(),
                                    return: 'false',
                                    authorization:"token "+authApi,
                                    type: jQuery("input[name='type']:checked").val()
                                    }, 
                                success:function(datos){ 
                                    console.log("precios");console.log(datos);
                                     jQuery('#latlngurbaner').val(marker2.getPosition().lat()+','+marker2.getPosition().lng());
                                     if(datos.error){    
                                        alert(datos.error);
                                        jQuery("#type1").prop("disabled", true);
                                        jQuery("#type3").prop("checked", true);
                                        //calculateRoute();
                                     }
                                     else{                                        
                                        jQuery("#type1").prop("disabled", false);
                                     }
                                     jQuery('body').trigger('update_checkout');
                                 }
                                });
                        }
                        calculateRoute();
                    }
                    catch(err) {
                      alert("Escriba su dirección de entrega y seleccione el punto en el mapa");
                    }
                    
                });

                //Poner Nombre direccion en el campo de Direccion
                function geocodePosition(pos) 
                {
                   geocoder = new google.maps.Geocoder();
                   geocoder.geocode
                    ({
                        latLng: pos
                    }, 
                        function(results, status) 
                        {
                            if (status == google.maps.GeocoderStatus.OK) 
                            {
                                jQuery("#billing_address_1").val(results[0].formatted_address);
                            } 
                        }
                    );
                }


                

            }