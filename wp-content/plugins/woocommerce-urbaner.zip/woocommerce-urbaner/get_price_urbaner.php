<?php
//ini_set('display_errors', 1); 
//error_reporting(E_ALL);

require(dirname(__FILE__,4).'/wp-blog-header.php');

if( isset($_POST['funcion']) ) {
  if($_POST['funcion'] == "calculatePrice"){
    calculatePrice(
        $_POST['authorization'],
        $_POST['latlngOrigin'], 
        $_POST['latlngDestination'], 
        $_POST['vehicle_id'], 
        $_POST['return'], 
        $_POST['type']);    
  }
} else {
  //require('/home/cementos/public_html/wp-blog-header.php');
  die("Solicitud no válida.");
  //$woocommerce;
  //var_dump(WC()->session->get( 'shipping_calculated_cost'));
  //$woocommerce_insta = $woocommerce->session->set( 'shipping_calculated_cost', $shipping_cost );
}

function calculatePrice( $auth, $latlngOrigin, $latlngDestination, $vehicle_id, $return, $type) {
    
   /* echo '{
                                "destinations": [
                                    {"latlon": "'.$latlngOrigin.'"},
                                    {"latlon": "'.$latlngDestination.'"}
                                ],
                                "package_type_id": '.$vehicle_id.',
                                "is_return": true
                             }';*/
    
    $curl = curl_init("https://api.sandbox.urbaner.com/api/cli/price/");                                                                      
                            curl_setopt($curl, CURLOPT_POST, 1);
                            curl_setopt($curl, CURLOPT_POSTFIELDS, '{
                                "destinations": [
                                    {"latlon": "'.$latlngOrigin.'"},
                                    {"latlon": "'.$latlngDestination.'"}
                                ],
                                "vehicle_type_id": '.$vehicle_id.',
                                "is_return": '.$return.'
                             }');

                            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);                                                                    
                            curl_setopt($curl, CURLOPT_HTTPHEADER, array(                                                                          
                                "Cache-Control: no-cache",
                                "Content-Type: application/json",
                                "Authorization: ".$auth
                                )                                                                       
                            );                                                                                                                                                                                                                                   
                                
                            $responseprecios = curl_exec($curl);
                            $responseprecios = json_decode($responseprecios,true);
                            
                            $err = curl_error($curl);
                            curl_close($curl);
    /*
            https://www.urbaner.com/developers/?shell#status-codes
            order_type_id   name
            1   Express
            2   Sameday
            3   Nextday
    */
            $preciosAislado = $responseprecios["prices"];
            $idEx = array_search('EXPRESS', array_column($preciosAislado, 'order_type'));
            $idNext = array_search('NEXTDAY', array_column($preciosAislado, 'order_type'));


  if( is_numeric($idEx) && is_numeric($idNext)){
        if($type == 1){            
            WC()->session->set( 'shipping_calculated_cost', $responseprecios["prices"][$idEx]["price"] );
        }
        else{
            if($type == 3){
                WC()->session->set( 'shipping_calculated_cost', $responseprecios["prices"][$idNext]["price"] );
            }
        }
  }
  else{
    if( is_numeric($idEx) && $type == 1){
        WC()->session->set( 'shipping_calculated_cost', $responseprecios["prices"][$idEx]["price"] );
      }
          else{
            if( is_numeric($idNext) && $type == 3){
                WC()->session->set( 'shipping_calculated_cost', $responseprecios["prices"][$idNext]["price"] );
              }
              else{
                $responseprecios["error"] = "Escoga otro Tipo de Vehiculo";
              }
      }      
  }

  //$respuesta = ["Respuestas",$idEx,$idNext,$responseprecios["prices"][$idEx]["price"],$responseprecios["prices"][$idNext]["price"], $errorq];
  header('Content-type: application/json; charset=utf-8');

  /*responseprecios*/

  echo json_encode($responseprecios, JSON_FORCE_OBJECT);
    //echo json_encode(custom_shipping_costs($rates), JSON_FORCE_OBJECT);
  
}



exit();