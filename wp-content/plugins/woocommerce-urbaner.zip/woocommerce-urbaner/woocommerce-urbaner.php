<?php
/*
  Plugin Name: Woocommerce Urbaner Plugin
  Plugin URI:  https://www.urbaner.com/developers/?text#create-order-cli-order/
  Description: Woocommerce Urbaner plugin.
  Version: 1.0
  Author: Vex Soluciones
  Text Domain: woocommerce-urbaner
  Copyright 2018 Vex Soluciones
 */

if (!defined('ABSPATH')) {
    exit(); // Exit if accessed directly
}

define('WUP_PATH', dirname(__FILE__));

include_once( WUP_PATH .'/includes/class-validate.php' );
//include_once(WUP_PATH .'/includes/class-shipping-method.php');

function urbaner_shipping_method() {
        if ( ! class_exists( 'TutsPlus_Shipping_Method' ) ) {
            class TutsPlus_Shipping_Method extends WC_Shipping_Method {
                /**
                 * Constructor for your shipping class
                 *
                 * @access public
                 * @return void
                 */
                protected $validate;

                public function __construct() {
                    $this->id                 = 'urbaner'; 
                    $this->method_title       = __( 'Urbaner', 'tutsplus' );  
                    $this->method_description = __( 'Metodo de envio Urbaner', 'tutsplus' ); 
 
                    $this->init();
 
                    $this->enabled = isset( $this->settings['enabled'] ) ? $this->settings['enabled'] : 'yes';
                    $this->title = isset( $this->settings['title'] ) ? $this->settings['title'] : __( 'Urbaner', 'tutsplus' );   
                    $this->latInit = $this->settings['latInit'];
                    $this->longInit = $this->settings['longInit'];
                    $this->urbanerApiKey = $this->settings['urbanerApiKey'];
                    $this->apiKeyGoogle = $this->settings['apiKeyGoogle'];

                    $this->personaContacto = $this->settings['personaContacto'];                    
                    $this->telefono = $this->settings['telefono'];                 
                    $this->direccion = $this->settings['direccion'];   
                    $this->latlon =   $this->settings['latInit'].', '.$this->settings['longInit'];
                    $this->interior = $this->settings['interior'];            
                    $this->referencia = $this->settings['referencia'];        
                    $this->correo = $this->settings['correo'];   
                    $this->tipoDePago = $this->settings['tipoDePago'];   
                    
                }
 
                /**
                 * Init your settings
                 *
                 * @access public
                 * @return void
                 */
                function init() {
                    // Load the settings API                 
                    $this->validate = new WGSP_Validate( $this );
                    $this->init_form_fields(); 
                    $this->init_settings(); 
                    // Save settings in admin if you have any defined
                    add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
                }
 
                /**
                 * Define settings field for this shipping
                 * @return void 
                 */
                function init_form_fields() { 

                    $license = get_option( 'woocommerce_urbaner-pe_license', '' );
                    $activated = get_option( 'woocommerce_urbaner-pe_activated', '0' );

                    if( !empty( $license ) && $activated ){
                      $this->form_fields = array( 
                     'enabled' => array(
                          'title' => __( 'Activar', 'tutsplus' ),
                          'type' => 'checkbox',
                          'description' => __( 'Activar este tipo de envio.', 'tutsplus' ),
                          'default' => 'yes'
                          ),

                     'draftorder' => array(
                          'title' => __( 'Modo de pruebas', 'tutsplus' ),
                          'type' => 'checkbox',
                          'description' => __( 'Generar ordenes de pruebas.', 'tutsplus' ),
                          'default' => 'yes'
                          ),
             
                     'title' => array(
                        'title' => __( 'Titulo', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Titulo para mostrar', 'tutsplus' ),
                          'default' => __( 'Urbaner', 'tutsplus' )
                          ),

                     'latInit' => array(
                        'title' => __( 'Latitud Inicial', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Latitud de la tienda', 'tutsplus' ),
                          'default' => __( '-77.0282400', 'tutsplus' )
                          ),

                     'longInit' => array(
                        'title' => __( 'Longitud Inicial', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Longitud de la tienda', 'tutsplus' ),
                          'default' => __( '-12.0431800', 'tutsplus' )
                          ),

                     'apiKeyGoogle' => array(
                        'title' => __( 'API Key de Google', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'API Key de Google', 'tutsplus' ),
                          'default' => __( 'AIzoSyDycZSwKf1alWn936tPCMf36HqGoOgLe-pg Ejemplo', 'tutsplus' )
                          ),

                      'urbanerApiKey' => array(
                        'title' => __( 'API key de Urbaner', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'API key de Urbaner', 'tutsplus' ),
                          'default' => __( '3909defe7a80b99cd46086b869ee3f7482735555 Ejemplo', 'tutsplus' )
                          ),

                      'urbanerApiKey' => array(
                        'title' => __( 'API key de Urbaner', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'API key de Urbaner', 'tutsplus' ),
                          'default' => __( '3909defe7a80b99cd46086b869ee3f7482735555 Ejemplo', 'tutsplus' )
                          ),

                      'personaContacto' => array(
                        'title' => __( 'Persona contacto', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Persona contacto', 'tutsplus' ),
                          'default' => __( 'VexSoluciones', 'tutsplus' )
                          ),

                      'telefono' => array(
                        'title' => __( 'Celular / Telefono', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Celular / Telefono', 'tutsplus' ),
                          'default' => __( '999555666', 'tutsplus' )
                          ),
                      'direccion' => array(
                        'title' => __( 'Direccion', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Direccion', 'tutsplus' ),
                          'default' => __( 'Cercado de Lima', 'tutsplus' )
                          ),
                      'interior' => array(
                        'title' => __( 'Interior', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Interior', 'tutsplus' ),
                          'default' => __( '5', 'tutsplus' )
                          ),
                      'referencia' => array(
                        'title' => __( 'Referencia de direccion', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Referencia', 'tutsplus' ),
                          'default' => __( 'Al frente de la iglesia', 'tutsplus' )
                          ),
                      'correo' => array(
                        'title' => __( 'Correo', 'tutsplus' ),
                          'type' => 'text',
                          'description' => __( 'Correo de contacto', 'tutsplus' ),
                          'default' => __( 'soporte@vexsoluciones.com', 'tutsplus' )
                          ),
                      'retorno' => array(
                        'title' => __( 'Retorno al punto de origen', 'tutsplus' ),
                          'type' => 'select',
                          'description' => __( 'Si el Courier retorna al punto de origen escoga "Si", de lo contrario escoga "No"', 'tutsplus' ),
                          'default' => 'no',
                          'options' => array(
                            'si' => __( 'Si', 'tutsplus' ),
                            'no'    => __( 'No', 'tutsplus' ),
                          )
                        ),

                      'tipoDePago' => array(
                        'title' => __( 'Tipo de pago', 'tutsplus' ),
                          'type' => 'select',
                          'description' => __( 'Escoga tipo de pago', 'tutsplus' ),
                          'default' => 'tarjeta',
                          'options' => array(
                            'purse' => __( 'Monedero Urbaner', 'tutsplus' ),
                            'credit'    => __( 'Tarjetas de Credito / Debito', 'tutsplus' ),
                          )
                        ),
             
                     );
                      return;                    
                    }
                    else{                      
                      $this->form_fields = $this->_license_fields();
                    }         
                }

                private function _license_fields(){
                  return array(
                    'code'    => array(
                      'title'   => __( 'License key', 'woocommerce-gateway-visanetperu' ),
                      'label'   => __( 'Enter the license key', 'woocommerce-gateway-visanetperu' ),
                      'type'    => 'text',
                      'default' => get_option( 'woocommerce_urbaner-pe_license', '' )
                    )
                  );
                }
 
                /**
                 * This function is used to calculate the shipping cost. Within this function we can check for weights, dimensions and other parameters.
                 *
                 * @access public
                 * @param mixed $package
                 * @return void
                 */
                public function calculate_shipping( $package ) {
                    
                    // We will add the cost, rate and logics in here
                    $rate = array(
                        'id' => $this->id,
                        'label' => $this->title,
                        'cost' => 20
                    );
 
                    $this->add_rate( $rate );
                    
                }     
            }

            add_action('wp_enqueue_scripts','gogolemaps_init');

    function gogolemaps_init() {

        //include WUP_PATH .'/includes/class-shipping-method.php';
        
      //require_once WUP_PATH .'/includes/class-shipping-method.php';

        
        $urbaner = new TutsPlus_Shipping_Method();
        wp_enqueue_script( 'initMap', plugin_dir_url( __FILE__ ) . 'js/urbaner.js' , '', '', true);
        wp_localize_script('initMap', 'myScript', array(
            'urbanerPluginUrl' => plugin_dir_url( __FILE__ ),
            'latInit' => $urbaner->latInit,
            'longInit' => $urbaner->longInit,
            'authApi' => $urbaner->urbanerApiKey
        ));
        wp_enqueue_style( 'styleUrbaner', plugin_dir_url( __FILE__ ) . '/css/urbaner.css',false,'','all');
        //AIzaSyDycZSwKf1axWn936tPCMf36HqSwGMp-pg
        wp_enqueue_script( 'googlemaps-async-defer', '//maps.googleapis.com/maps/api/js?key='.
          $urbaner->apiKeyGoogle.'&libraries=places&sensor=false&callback=initMap', '', '', true );
    }


add_action('woocommerce_checkout_before_order_review', function(){
  $chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
    $chosen_shipping = $chosen_methods[0]; 
     
    $urbaner = new TutsPlus_Shipping_Method();
    if($urbaner->enabled == 'yes')
    {
        ?>
        <div class="urbaner-map-template">      
            <h2>Seleccione punto de envío</h2>
            <div id="map" style="width: auto;height: 400px"></div> 
            <div class="urbaner-options">
              
              <div class="row urbaner-options">
              <div class="col-sm-6">
                <div><h4 style="display: flex; align-items: center; margin: 0px; text-transform: uppercase;"><div style="margin: 10px;"><svg viewBox="0 0 512 512" width="2em" height="2em"><path d="M181.518 272h-60.002c2.915 25.908 12.984 49.429 28.477 68.796l42.502-42.502c-5.215-7.866-9.029-16.736-10.977-26.294zM213.706 319.505l-42.502 42.502c19.367 15.493 42.889 25.562 68.796 28.477v-60.002c-9.558-1.948-18.428-5.762-26.294-10.977zM171.204 149.993l42.502 42.502c7.866-5.215 16.736-9.029 26.294-10.977v-60.002c-25.908 2.915-49.429 12.984-68.796 28.477zM149.993 171.204C134.5 190.571 124.431 214.092 121.516 240h60.002c1.948-9.558 5.762-18.428 10.977-26.294l-42.502-42.502zM272 121.516v60.002c9.558 1.948 18.428 5.762 26.294 10.977l42.502-42.502C321.429 134.5 297.908 124.431 272 121.516zM330.482 272c-1.948 9.558-5.762 18.428-10.977 26.294l42.502 42.502c15.493-19.367 25.562-42.889 28.477-68.796h-60.002z"></path><path d="M257 0C116.39 0 0 114.39 0 255s116.39 257 257 257 255-116.39 255-257S397.61 0 257 0zm0 422c-90.981 0-167-76.019-167-167S166.019 90 257 90s165 74.019 165 165-74.019 167-165 167z"></path><path d="M362.007 171.204l-42.502 42.502c5.215 7.866 9.029 16.736 10.977 26.294h60.002c-2.915-25.908-12.984-49.429-28.477-68.796zM298.294 319.505c-7.866 5.215-16.736 9.029-26.294 10.977v60.002c25.908-2.915 49.429-12.984 68.796-28.477l-42.502-42.502zM288.817 223.208c-.004-.004-.011-.005-.011-.005s-.009-.015-.013-.018c-17.597-17.585-47.989-17.585-65.585 0-.004.004-.005.011-.005.011s-.015.009-.018.013C215.043 231.354 210 242.598 210 255c0 15.534 9.768 32.941 13.195 33.798 9.167 14.667 45.003 20.6 65.598.018.003-.003.005-.011.009-.014 0 0 .011-.005.015-.009 17.585-17.597 17.585-47.989 0-65.585z"></path></svg></div> Tipo de Servicio</h4><div class="e-box-material u-align-center c-service-type sc-dqBHgY cZcnCa"><div class="u-flex-center u-flex-undefined u-flex-evenly "><div style="width: inherit;"><label class="u-flex-center  
            u-flex-evenly
             
            " style="padding: inherit;display: flex"><input id="type1" name="type" type="radio" value="1" checked="" style="order: 1;"> <div style="order: 2; display: inline-flex; align-items: center;"><div style=""><svg width="1.5em" height="1.5em" viewBox="0 0 24 24"><title>Icono/Express</title><path d="M18.934 10.57c-.087-.218-.261-.326-.512-.326h-4.867l2.418-6.502c.106-.281.014-.495-.22-.654a.564.564 0 0 0-.683.06l-9.884 9.637c-.172.167-.212.377-.12.614.088.229.26.339.511.339h4.867l-2.418 6.51c-.105.282-.016.49.22.644.156.104.47.149.703-.078l9.864-9.638c.172-.167.215-.368.12-.605zm-9.002 7.743l1.827-4.933a.53.53 0 0 0-.512-.735H6.932l7.135-6.976-1.837 4.942a.506.506 0 0 0 .07.487.522.522 0 0 0 .452.247h4.315l-7.135 6.968z" fill-rule="nonzero" fill="#000"></path></svg></div></div><div class="undefined" style="order: 3; display: flex; flex-flow: column; flex-grow: inherit; flex-basis: 190px; padding: initial; text-align: inherit; text-transform: capitalize;"><span style="font-weight: bold; display: flex;">Express</span></div></label></div><div style="width: inherit;"><label class="u-flex-center  
            u-flex-evenly
             
            " style="padding: inherit;display: flex"><input id="type3" name="type" type="radio" value="3" style="order: 1;"> <div style="order: 2; display: inline-flex; align-items: center;"><div style=""><svg data-name="\u56FE\u5C42 1" viewBox="0 0 40 40" width="1.5em" height="1.5em"><title>nextdayMesa de trabajo 1</title><path d="M33.49 32.42H9a4.87 4.87 0 0 1-4.68-3.24 4.38 4.38 0 0 1 .36-4 4.45 4.45 0 0 1 3.42-2.16l.9-.18c.18 0 .36-.18.54-.36l.36-.9a6.41 6.41 0 0 1 5.76-4.14 8.85 8.85 0 0 1 1.8.18c.36 0 .54-.18.54-.36l.36-.72a7.39 7.39 0 0 1 6.48-4.5h.36a7.61 7.61 0 0 1 7.56 7.56c0 .36-.27 2-.27 2-.15.78.09 1.27.45 1.27l1.26.18a4.79 4.79 0 0 1 4 3.78 5.15 5.15 0 0 1-1.08 4 4.53 4.53 0 0 1-3.63 1.59zM15.67 19.28a4.54 4.54 0 0 0-4.14 2.88l-.36.9a2.59 2.59 0 0 1-2 1.62l-.9.18a3 3 0 0 0-2.14 1.44A2.5 2.5 0 0 0 6 28.82a3.17 3.17 0 0 0 2.88 2h24.61a3.17 3.17 0 0 0 2.34-1.08 3.12 3.12 0 0 0 .54-2.52 3.08 3.08 0 0 0-2.52-2.34l-1.26-.18a2.41 2.41 0 0 1-2-2.7l.18-1.44v-.9A5.8 5.8 0 0 0 25 13.88h-.18c-2.16 0-4 1.44-5 3.6l-.36.72a2.16 2.16 0 0 1-2.16 1.44c-.96-.1-1.23-.33-1.63-.36zM13.33 11.18a.85.85 0 0 1-.9-.9v-1.8a.9.9 0 0 1 1.8 0v1.8a1.16 1.16 0 0 1-.9.9zM4.51 20h-1.8a.9.9 0 0 1 0-1.8h1.8a.85.85 0 0 1 .9.9 1 1 0 0 1-.9.9zM7 13.7a1.08 1.08 0 0 1-.72-.18l-1.23-1.26A.89.89 0 1 1 6.31 11l1.26 1.26a.87.87 0 0 1 0 1.26c-.18 0-.36.18-.57.18z"></path><path d="M19.45 13.88a1.08 1.08 0 0 1-.72-.18.87.87 0 0 1 0-1.26L20.17 11a.89.89 0 1 1 1.26 1.26L20 13.52c-.19.18-.37.36-.55.36zM9.19 24.32A6.43 6.43 0 0 1 7 19.46a6.64 6.64 0 0 1 6.66-6.66 6.31 6.31 0 0 1 6.18 4.34l-1.68.7a4.82 4.82 0 1 0-7.74 5.22z"></path></svg></div></div><div class="undefined" style="order: 3; display: flex; flex-flow: column; flex-grow: inherit; flex-basis: 190px; padding: initial; text-align: inherit; text-transform: capitalize;"><span style="font-weight: bold; display: flex;">nextday</span></div></label></div><div style="width: inherit;"></div></div></div></div>
              </div>
              <div class="col-sm-6">
                <div><h4 style="display: flex; align-items: center; margin: 0px; text-transform: uppercase;"><div style="margin: 10px;"><svg viewBox="0 0 486.736 486.736" width="2em" height="2em"><path d="M481.883 61.238l-474.3 171.4c-8.8 3.2-10.3 15-2.6 20.2l70.9 48.4 321.8-169.7-272.4 203.4v82.4c0 5.6 6.3 9 11 5.9l60-39.8 59.1 40.3c5.4 3.7 12.8 2.1 16.3-3.5l214.5-353.7c1.8-2.9-1.1-6.5-4.3-5.3z"></path></svg></div> Elige un Vehiculo</h4><div class="e-box-material sc-dqBHgY cZcnCa"><div class="u-flex-center u-flex-column u-flex-evenly "><div style="width: 100%;"><label class="u-flex-center  
            u-width-100 u-flex-between
            u-combobox-selected 
            " style="padding: 1em 2em;"><input name="package_type.id" type="radio" value="1" style="order: 3;float:left"> <img width="24" src="https://api.sandbox.urbaner.com/media/packages/bici.png" alt="icon" style="order: 1;float:left"><div class="vehicle-service-label" style="order: 2; display: flex; flex-flow: column; flex-grow: inherit; flex-basis: 190px; padding: initial; text-align: inherit; align-items: center;float:left;margin-left: 10px"><span style="font-weight: bold; display: flex;">Bicicleta</span></div></label></div><div style="width: 100%;"><label class="u-flex-center  
            u-width-100 u-flex-between
             
            " style="padding: 1em 2em;"><input name="package_type.id" type="radio" value="2" checked="" style="order: 3;float:left"> <img width="24" src="https://api.sandbox.urbaner.com/media/packages/moto.png" alt="icon" style="order: 1;float:left"><div class="vehicle-service-label" style="order: 2; display: flex; flex-flow: column; flex-grow: inherit; flex-basis: 190px; padding: initial; text-align: inherit; align-items: center;float:left;margin-left: 10px"><span style="font-weight: bold; display: flex;">Moto</span></div></label></div><div style="width: 100%;"><label class="u-flex-center  
            u-width-100 u-flex-between
             
            " style="padding: 1em 2em;"><input name="package_type.id" type="radio" value="3" style="order: 3;float:left"> <img width="24" src="https://api.sandbox.urbaner.com/media/packages/auto.png" alt="icon" style="order: 1;float:left"><div class="vehicle-service-label" style="order: 2; display: flex; flex-flow: column; flex-grow: inherit; flex-basis: 190px; padding: initial; text-align: inherit; align-items: center;float:left;margin-left: 10px"><span style="font-weight: bold; display: flex;float:left">Auto</span></div></label></div></div>
            
        </div>
    </div>
  </div>
  </div>
              
            </div>


              </div>
            <!--/div>
            


            

        </div-->
        <?php
    }
});


add_action('woocommerce_checkout_update_order_meta', 'customise_checkout_field_update_order_meta_chazki');
 
function customise_checkout_field_update_order_meta_chazki($order_id)
{       
    if (!empty($_POST['latlngurbaner'])) {
        update_post_meta($order_id, 'latlngurbaner', sanitize_text_field($_POST['latlngurbaner']));
    }

  //update_post_meta($order_id, 'latlngurbaner', sanitize_text_field($_POST['latlngurbaner']));
}

/**
 * Add the field to the checkout page
 */
add_action('woocommerce_after_order_notes', 'customise_checkout_field_chazki');
 
function customise_checkout_field_chazki($checkout)
{
  echo '<div id="customise_checkout_field">';
  woocommerce_form_field('latlngurbaner', array(
    'type' => 'text',
    'class' => array(
      'latlngurbaner-form form-row-wide'
    ) ,
    'label' => __('Customise Additional Field') ,
    'placeholder' => __('Guidence') ,
    'required' => false,
  ) , $checkout->get_value('latlngurbaner'));
  echo '</div>';
}



add_action( 'woocommerce_order_status_completed', 'wc_send_order_urbaner_to_mypage' );
function wc_send_order_urbaner_to_mypage( $order_id ) {
/*$shipping_add = [
           $this->personaContacto = $this->settings['personaContacto'];                    
                    $this->telefono = $this->settings['telefono'];                 
                    $this->direccion = $this->settings['direccion'];   
                    $this->latlon =   $this->settings['latInit'].', '.$this->settings['longInit'];
                    $this->interior = $this->settings['interior'];            
                    $this->referencia = $this->settings['referencia'];        
                    $this->correo 
        ];*/
        

        $order = wc_get_order($order_id);

        $order_data = $order->get_data(); 

        $urbaner = new TutsPlus_Shipping_Method();

        $personaComercio = $urbaner->personaContacto;
        $celComercio= $urbaner->telefono;
        $direccionComercio= $urbaner->direccion;
        $latlonComercio= $urbaner->latlon;
        $intComercio= $urbaner->interior;
        $referenciaComercio= $urbaner->referencia;
        $emailComercio=$urbaner->correo;
        $tipoPago = $urbaner->tipoDePago;
        $return = 'false';
        $search = 'false';
        $vehicle_id = "2";
        $apiKey = $urbaner->urbanerApiKey;
        $latlonDestino = get_post_meta($order->get_order_number(), 'latlngurbaner', true);
        
        $orderWoo_id = 'Orden #'.$order_id;
        $orderShipping = $order->get_total_shipping();

        $customer_firstname = ($order->get_shipping_first_name() == "") ? $order->get_billing_first_name() : $order->get_shipping_first_name();
        $customer_lastname = ($order->get_shipping_last_name() == "") ? $order->get_billing_last_name() : $order->get_shipping_last_name();
        $correo = $order->get_billing_email();
        $customer_phone = $order->get_billing_phone();
        $street1 = ($order->get_shipping_address_1() == "") ? $order->get_billing_address_1() : $order->get_shipping_address_1();
        $nota = $order->get_customer_note();

        $customerCountry = ($order->get_shipping_country() == "") ? $order->get_billing_country() : $order->get_shipping_country();
        

        // Return an array of shipping costs within this order.
        $order->get_shipping_methods(); 

        // Conditional function based on the Order shipping method 
        if( $order->has_shipping_method('urbaner') ) { 
            $order = wc_get_order(  $order_id );
            

            $CURL_REQUEST = '{
                                "type": "1",
                                "destinations": [
                                {
                                  "contact_person": "'.$personaComercio.'",
                                  "phone": "'.$celComercio.'",
                                  "address": "'.$direccionComercio.'",
                                  "latlon": "'.$latlonComercio.'",
                                  "interior": "'.$intComercio.'",
                                  "special_instructions": "'.$referenciaComercio.'",
                                  "email": "'.$emailComercio.'"
                                },
                                {
                                  "contact_person": "'.$customer_firstname." ".$customer_lastname.'",
                                  "phone": "'.$customer_phone.'",
                                  "address": "'.$street1.'",
                                  "latlon": "'.$latlonDestino.'",
                                  "interior": "'.$nota.'",
                                  "special_instructions": "'.$nota.'",
                                  "email": "'.$correo.'"
                                }
                                ],
                                "payment": {
                                    "backend": "'.$tipoPago.'"
                                },
                                "description": "Comida",
                                "vehicle_id": "'.$vehicle_id.'",
                                "memo": "'.$orderWoo_id.'",
                                "is_return": "'.$return.'",
                                "has_extended_search_time": "'.$search.'"
                            }';
            // Add the note

                    $curl = curl_init("https://api.sandbox.urbaner.com/api/cli/order/");  
                    /*curl_setopt($curl, CURLOPT_VERBOSE, 1);
                    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($curl,CURLOPT_CONNECTTIMEOUT, 0);*/ 
                    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);  
                    curl_setopt($curl, CURLOPT_POST, 1);

                    curl_setopt($curl, CURLOPT_POSTFIELDS, $CURL_REQUEST);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);                                                                                       
                    curl_setopt($curl, CURLOPT_HTTPHEADER, array(                                                                          
                            "Cache-Control: no-cache",
                            "Content-Type: application/json",
                            "Authorization: token ".$apiKey
                            )                                                         
                        );     

                    $response = curl_exec($curl);
                    
                    $response = json_decode($response,true);
                    $err = curl_error($curl);

                    curl_close($curl);

                    if ($err) {
                        $order->add_order_note($err);
                         //$order->update_meta_data( 'chazki_delivery_track', $err );
                         //$order->update_meta_data( 'latlngchazki', WC()->session->get( 'latlngchazki'));
                    } else {
                        //$order->update_meta_data( 'chazki_delivery_track', $response['codeDelivery'] );
                         //$order->update_meta_data( 'latlngchazki', WC()->session->get( 'latlngchazki'));
                        //$order->add_order_note($response['codeDelivery']);
                        $order->add_order_note('<pre>'.$response.'</pre>');
                    }

            $order->add_order_note( $CURL_REQUEST );

            // Save the data
            $order->save();
        }
        
}


        }//fin if class
    }// fin funcino urbaner


    add_action( 'woocommerce_shipping_init', 'urbaner_shipping_method' );

    function add_urbaner_shipping_method( $methods ) {
        $methods[] = 'TutsPlus_Shipping_Method';
        return $methods;
    }
 
    add_filter( 'woocommerce_shipping_methods', 'add_urbaner_shipping_method' );

if ( ! class_exists( 'TutsPlus_Shipping_Method' ) ) {

    

}
else{
    //echo 'no existe';
}

    

add_action('admin_notices', 'wp_urbaner_admin_notice');
function wp_urbaner_admin_notice() {
    if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {

        echo '<div class="error"><p>' . __('WooCommerce Urbaner requires woocoomerce plugin to be installed before..', 'woocommerce-pickup-location') . '</p></div>';

        deactivate_plugins('woocommerce-urbaner/woocommerce-urbaner.php');
    }
}

add_filter('woocommerce_package_rates', 'update_shipping_costs_based_on_cart_session_custom_data', 10, 2);
function update_shipping_costs_based_on_cart_session_custom_data( $rates, $package ){

    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return $rates;

    // SET HERE the default cost (when "calculated cost" is not yet defined)
    $cost = '0';

    // Get Shipping rate calculated cost (if it exists)
    $calculated_cost = WC()->session->get( 'shipping_calculated_cost');

    // Iterating though Shipping Methods
    foreach ( $rates as $rate_key => $rate_values ) {
        $method_id = $rate_values->method_id;
        $rate_id = $rate_values->id;
        // For "Flat rate" Shipping" Method only
        if ( 'urbaner' === $method_id ) {
            if( ! empty( $calculated_cost ) ) {
                $cost = $calculated_cost;
            }
            // Set the rate cost
            $rates[$rate_id]->cost = $cost;
            /* Taxes rate cost (if enabled)
            foreach ($rates[$rate_id]->taxes as $key => $tax){
                if( $rates[$rate_id]->taxes[$key] > 0 ){ // set the new tax cost
                    $taxes[$key] = number_format( $rates[$rate_id]->taxes[$key] * $cost, 2 );
                    $has_taxes = true;
                } else {
                    $has_taxes = false;
                }
            }
            if( $has_taxes )
                $rates[$rate_id]->taxes = $taxes;*/
        }
    }
    return $rates;
}




/*add_filter( 'woocommerce_update_order_review_fragments', 'my_custom_shipping_table_update');
//add_action( 'woocommerce_shipping_method_chosen', 'my_custom_shipping_table_update', 10, 1 );
function my_custom_shipping_table_update( $fragments ) {
    
     
    ob_start();
    ?>
    <
    <?php

    $chosen_methods = WC()->session->get( 'chosen_shipping_methods' );
 	$chosen_shipping = $chosen_methods[0]; 
    $woocommerce_shipping_methods = ob_get_clean();
    if ($chosen_shipping == 'urbaner') {
    	$fragments['.urbaner-options'] = $woocommerce_shipping_methods;
    }
    else   {
    	 $fragments['.urbaner-options'] = '<div class="urbaner-options"></div>';
    }
    
    
    return $fragments;
}*/
//$plugin = new TutsPlus_Shipping_Method();
function add_asyncdefer_attribute($tag, $handle)
{
    $param = '';
    if ( strpos($handle, 'async') !== false ) $param = 'async ';
    if ( strpos($handle, 'defer') !== false ) $param .= 'defer ';
    if ( $param )
        return str_replace('<script ', '<script ' . $param, $tag);
    else
        return $tag;
}
add_filter('script_loader_tag', 'add_asyncdefer_attribute', 10, 2);





add_action('woocommerce_review_order_before_payment', function(){
            //include 'wp-urbaner-map.php';
            echo '<div class="urbaner-map-template"></div>';
        });


